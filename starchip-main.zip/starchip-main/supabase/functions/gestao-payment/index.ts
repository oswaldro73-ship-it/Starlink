import { serve } from "https://deno.land/std@0.190.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Credenciais Gestão Pay
const PUBLIC_KEY = "gestaopay_live_tHPUMHa9HEBGT3WrWqAHCQnKd8EnQgmX";
const SECRET_KEY = "sk_live_VzE3AJOqmhc04A9I2d1I0cl6pVBj80md";
const AUTH_HEADER = `Basic ${btoa(`${PUBLIC_KEY}:${SECRET_KEY}`)}`;

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { action, payload, transactionId } = await req.json()

    console.log(`[gestao-payment] Action: ${action}`);

    // Ação de criar transação
    if (action === 'create') {
        console.log(`[gestao-payment] Creating transaction...`);
        const response = await fetch('https://api.gestaopayments.com/v1/payment-transaction/create', {
            method: 'POST',
            headers: {
                'Authorization': AUTH_HEADER,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        
        const data = await response.json();
        console.log(`[gestao-payment] Create response:`, data);
        
        return new Response(JSON.stringify(data), { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        })
    }

    // Ação de verificar status (ATUALIZADA)
    if (action === 'check') {
         if (!transactionId) {
             throw new Error("Transaction ID is required for check action");
         }
         console.log(`[gestao-payment] Checking transaction ${transactionId}...`);
         
         // Endpoint atualizado para /info/{id} conforme documentação
         const response = await fetch(`https://api.gestaopayments.com/v1/payment-transaction/info/${transactionId}`, {
            method: 'GET',
            headers: {
                'Authorization': AUTH_HEADER,
                'Accept': 'application/json'
            }
        });
        
        const data = await response.json();
        
        // Log para debug
        console.log(`[gestao-payment] Check status:`, data.success ? data.data?.status : 'Error');

        return new Response(JSON.stringify(data), { 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        })
    }

    return new Response(JSON.stringify({ error: 'Invalid action' }), { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    })

  } catch (error) {
    console.error(`[gestao-payment] Error:`, error);
    return new Response(JSON.stringify({ error: error.message }), { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    })
  }
})