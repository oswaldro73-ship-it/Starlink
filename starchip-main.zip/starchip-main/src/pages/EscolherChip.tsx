import { useState, useEffect } from "react";
import { useLocation, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Smartphone, Zap, Check, Package, Truck, Clock, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const EscolherChip = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const location = useLocation();
  const navigate = useNavigate();
  const [selectedType, setSelectedType] = useState<"virtual" | "fisico">("virtual");

  // Plano padrão caso a navegação seja direta
  const defaultPlan = {
    id: 2,
    gb: "450 GB",
    price: "49,00",
    popular: true,
  };

  const plan = location.state?.plan || defaultPlan;
  
  const planPrice = parseFloat(plan.price.replace(",", "."));
  const shippingCost = selectedType === "virtual" ? 0 : 9.99;
  const total = planPrice + shippingCost;

  const handleNextStep = () => {
    navigate("/escolher-numero", { 
      state: { 
        plan, 
        type: selectedType, 
        total,
        shippingCost
      } 
    });
  };

  return (
    <div className="min-h-screen bg-background font-sans antialiased">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link to="/" className="flex items-center gap-3">
            <img 
              src="/starlogo.png" 
              alt="Starlink" 
              className="h-12 w-auto object-contain" 
            />
            <span className="text-foreground font-semibold"></span>
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        <Link to="/#ativar" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors">
          <ArrowLeft className="h-4 w-4" />
          Voltar para planos
        </Link>

        <div className="bg-card border border-border rounded-xl p-4 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Plano selecionado</p>
              <p className="text-xl font-bold text-foreground">Chip Starlink {plan.gb}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Valor do chip</p>
              <p className="text-xl font-bold text-foreground">R$ {plan.price}</p>
            </div>
          </div>
        </div>

        <div className="text-center mb-10">
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-3">
            Como você prefere receber seu chip?
          </h1>
          <p className="text-muted-foreground">
            Escolha entre o chip virtual (eSIM) ou o chip físico tradicional
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-10">
          {/* Chip Virtual Card */}
          <div 
            onClick={() => setSelectedType("virtual")}
            className={`relative p-6 rounded-2xl border-2 cursor-pointer transition-all bg-card ${
              selectedType === "virtual" 
                ? "border-green-600 ring-1 ring-green-600/20" 
                : "border-border hover:border-foreground/50"
            }`}
          >
            <div className="absolute -top-3 left-1/2 -translate-x-1/2">
              <span className="bg-green-600 text-white px-4 py-1 rounded-full text-xs font-semibold">
                Recomendado
              </span>
            </div>
            
            <div className="flex items-center gap-4 mb-4 mt-2">
              <div className="w-14 h-14 rounded-xl bg-foreground/10 flex items-center justify-center">
                <Smartphone className="h-7 w-7 text-foreground" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground">Chip Virtual (eSIM)</h3>
                <p className="text-green-600 font-semibold text-sm">Envio Grátis</p>
              </div>
            </div>

            <ul className="space-y-3 mb-6">
              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-5 h-5 rounded-full bg-green-600/20 flex items-center justify-center mt-0.5">
                  <Zap className="h-3 w-3 text-green-600" />
                </div>
                <span className="text-foreground text-sm">
                  <strong>Ativação no mesmo dia</strong> - Receba por e-mail e ative em minutos
                </span>
              </li>
              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-5 h-5 rounded-full bg-green-600/20 flex items-center justify-center mt-0.5">
                  <Check className="h-3 w-3 text-green-600" />
                </div>
                <span className="text-foreground text-sm">
                  <strong>Sem ocupar espaço físico</strong> - Funciona junto com seu chip atual
                </span>
              </li>
              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-5 h-5 rounded-full bg-green-600/20 flex items-center justify-center mt-0.5">
                  <Check className="h-3 w-3 text-green-600" />
                </div>
                <span className="text-foreground text-sm">
                  <strong>Compatível com a maioria</strong> dos smartphones modernos (iPhone, Samsung, etc.)
                </span>
              </li>
            </ul>

            <div className="border-t border-border pt-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-muted-foreground text-sm">Chip Starlink {plan.gb}</span>
                <span className="text-foreground">R$ {plan.price}</span>
              </div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-muted-foreground text-sm">Taxa de envio</span>
                <span className="text-green-600 font-semibold">Grátis</span>
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-border">
                <span className="text-foreground font-bold">Total</span>
                <span className="text-2xl font-bold text-foreground">R$ {plan.price}</span>
              </div>
            </div>

            <div className={`absolute top-4 right-4 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
              selectedType === "virtual" 
                ? "border-green-600 bg-green-600" 
                : "border-muted-foreground"
            }`}>
              {selectedType === "virtual" && <Check className="h-4 w-4 text-white" />}
            </div>
          </div>

          {/* Chip Físico Card */}
          <div 
            onClick={() => setSelectedType("fisico")}
            className={`relative p-6 rounded-2xl border-2 cursor-pointer transition-all bg-card ${
              selectedType === "fisico" 
                ? "border-foreground ring-1 ring-foreground/20" 
                : "border-border hover:border-foreground/50"
            }`}
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="w-14 h-14 rounded-xl bg-foreground/10 flex items-center justify-center">
                <Package className="h-7 w-7 text-foreground" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground">Chip Físico</h3>
                <p className="text-muted-foreground font-semibold text-sm">+ R$ 9,99 de entrega</p>
              </div>
            </div>

            <ul className="space-y-3 mb-6">
              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-5 h-5 rounded-full bg-foreground/20 flex items-center justify-center mt-0.5">
                  <Truck className="h-3 w-3 text-foreground" />
                </div>
                <span className="text-foreground text-sm">
                  <strong>Entrega em até 7 dias úteis</strong> - Enviamos para todo o Brasil
                </span>
              </li>
              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-5 h-5 rounded-full bg-foreground/20 flex items-center justify-center mt-0.5">
                  <Clock className="h-3 w-3 text-foreground" />
                </div>
                <span className="text-foreground text-sm">
                  <strong>Ativação após recebimento</strong> - Suporte completo para configuração
                </span>
              </li>
              <li className="flex items-start gap-3">
                <div className="flex-shrink-0 w-5 h-5 rounded-full bg-foreground/20 flex items-center justify-center mt-0.5">
                  <Check className="h-3 w-3 text-foreground" />
                </div>
                <span className="text-foreground text-sm">
                  <strong>Compatível com todos</strong> os celulares com slot para chip
                </span>
              </li>
            </ul>

            <div className="border-t border-border pt-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-muted-foreground text-sm">Chip Starlink {plan.gb}</span>
                <span className="text-foreground">R$ {plan.price}</span>
              </div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-muted-foreground text-sm">Taxa de envio</span>
                <span className="text-foreground">R$ 9,99</span>
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-border">
                <span className="text-foreground font-bold">Total</span>
                <span className="text-2xl font-bold text-foreground">
                  R$ {total.toFixed(2).replace(".", ",")}
                </span>
              </div>
            </div>

            <div className={`absolute top-4 right-4 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
              selectedType === "fisico" 
                ? "border-foreground bg-foreground" 
                : "border-muted-foreground"
            }`}>
              {selectedType === "fisico" && <Check className="h-4 w-4 text-background" />}
            </div>
          </div>
        </div>

        <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl p-4 mb-8">
          <p className="text-blue-800 dark:text-blue-200 text-sm text-center">
            <strong>Não se preocupe!</strong> Independente da escolha, você poderá usar o chip Starlink junto com seu chip atual. Você receberá um novo número e poderá usar os dois simultaneamente.
          </p>
        </div>

        <div className="text-center">
          <Button 
            size="lg" 
            className="text-lg px-12 py-6 h-auto group rounded-full"
            onClick={handleNextStep}
          >
            Escolher meu número
            <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Button>
          <p className="text-center text-sm text-muted-foreground mt-4">
            Pagamento seguro via PIX
          </p>
        </div>
      </main>
    </div>
  );
};

export default EscolherChip;