import { useState, useEffect } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Phone, RefreshCw, Sparkles, Search, Check, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// Dados de DDDs organizados por região
const REGIONS = [
  { name: "SP - Capital", ddds: ["11"] },
  { name: "SP - Interior", ddds: ["12", "13", "14", "15", "16", "17", "18", "19"] },
  { name: "RJ", ddds: ["21", "22", "24"] },
  { name: "ES", ddds: ["27", "28"] },
  { name: "MG", ddds: ["31", "32", "33", "34", "35", "37", "38"] },
  { name: "PR", ddds: ["41", "42", "43", "44", "45", "46"] },
  { name: "SC", ddds: ["47", "48", "49"] },
  { name: "RS", ddds: ["51", "53", "54", "55"] },
  { name: "DF", ddds: ["61"] },
  { name: "GO", ddds: ["62", "64"] },
  { name: "MT", ddds: ["65", "66"] },
  { name: "MS", ddds: ["67"] },
  { name: "AC", ddds: ["68"] },
  { name: "RO", ddds: ["69"] },
  { name: "BA", ddds: ["71", "73", "74", "75", "77"] },
  { name: "SE", ddds: ["79"] },
  { name: "PE", ddds: ["81", "87"] },
  { name: "AL", ddds: ["82"] },
  { name: "PB", ddds: ["83"] },
  { name: "RN", ddds: ["84"] },
  { name: "CE", ddds: ["85", "88"] },
  { name: "PI", ddds: ["86", "89"] },
  { name: "MA", ddds: ["98", "99"] },
  { name: "PA", ddds: ["91", "93", "94"] },
  { name: "AM", ddds: ["92", "97"] },
  { name: "RR", ddds: ["95"] },
  { name: "AP", ddds: ["96"] },
  { name: "TO", ddds: ["63"] },
];

const EscolherNumero = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state || {};
  
  // Dados vindos da tela anterior
  const plan = state.plan || { gb: "450 GB", price: "49,00" };
  const type = state.type || "virtual";
  const shippingCost = state.shippingCost || 0;
  const total = state.total || 49.00;

  // Estados
  const [selectedDDD, setSelectedDDD] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [centralDigits, setCentralDigits] = useState("9" + Math.floor(Math.random() * 10000).toString().padStart(4, "0"));
  const [lastFour, setLastFour] = useState("");
  const [isAnimating, setIsAnimating] = useState(false);

  // Filtrar regiões com base na busca
  const filteredRegions = REGIONS.map(region => {
    // Se o termo de busca corresponder ao nome da região
    if (region.name.toLowerCase().includes(searchTerm.toLowerCase())) {
      return region;
    }
    // Ou se corresponder a algum DDD dentro da região
    const filteredDDDs = region.ddds.filter(ddd => ddd.includes(searchTerm));
    if (filteredDDDs.length > 0) {
      return { ...region, ddds: filteredDDDs };
    }
    return null;
  }).filter(Boolean) as typeof REGIONS;

  const generateCentralDigits = () => {
    setIsAnimating(true);
    // Efeito de "embaralhar" números
    let interval = setInterval(() => {
      setCentralDigits("9" + Math.floor(Math.random() * 10000).toString().padStart(4, "0"));
    }, 50);

    setTimeout(() => {
      clearInterval(interval);
      setCentralDigits("9" + Math.floor(Math.random() * 10000).toString().padStart(4, "0"));
      setIsAnimating(false);
    }, 500);
  };

  const handleLastFourChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "").slice(0, 4);
    setLastFour(value);
  };

  const handleContinue = () => {
    if (!selectedDDD) {
      toast.error("Por favor, selecione um DDD.");
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    
    if (lastFour.length !== 4) {
      toast.error("Por favor, preencha os 4 últimos dígitos.");
      return;
    }

    navigate("/checkout", { 
      state: { 
        plan, 
        type, 
        shippingCost,
        total,
        selectedDDD,
        centralDigits,
        lastFour
      } 
    });
  };

  return (
    <div className="min-h-screen bg-background font-sans antialiased">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link to="/" className="flex items-center gap-3">
             <img 
              src="/starlogo.png" 
              alt="Starlink" 
              className="h-12 w-auto object-contain" 
            />
            <span className="text-foreground font-semibold"></span>
          </Link>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        <button 
          onClick={() => navigate(-1)} 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Voltar
        </button>

        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 mb-4 rounded-full border border-border bg-card">
            <Phone className="h-4 w-4 text-foreground" />
            <span className="text-sm font-medium text-foreground">Personalize seu número</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-3 text-balance">
            Escolha o número do seu Chip Starlink
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Selecione o DDD da sua região e escolha os últimos 4 dígitos do seu novo número. Os dígitos centrais são gerados automaticamente.
          </p>
        </div>

        <div className="space-y-8">
          {/* Passo 1: Escolha do DDD */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-full bg-foreground text-background flex items-center justify-center text-sm font-bold">1</div>
              <h2 className="text-lg font-semibold text-foreground">Escolha seu DDD</h2>
            </div>
            
            <div className="mb-4 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Buscar por estado ou DDD..." 
                className="pl-9 h-10 bg-background border-border text-foreground"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="max-h-64 overflow-y-auto pr-1 space-y-3 custom-scrollbar">
              {filteredRegions.length > 0 ? (
                filteredRegions.map((region, idx) => (
                  <div key={idx}>
                    <p className="text-xs font-medium text-muted-foreground mb-1.5">{region.name}</p>
                    <div className="flex flex-wrap gap-2">
                      {region.ddds.map((ddd) => (
                        <button
                          key={ddd}
                          onClick={() => setSelectedDDD(ddd)}
                          className={cn(
                            "px-4 py-2 rounded-lg text-sm font-medium transition-all border",
                            selectedDDD === ddd
                              ? "bg-foreground text-background border-foreground shadow-sm"
                              : "bg-foreground/5 text-foreground hover:bg-foreground/10 border-border"
                          )}
                        >
                          {ddd}
                        </button>
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">Nenhum DDD encontrado.</p>
              )}
            </div>
            
            {selectedDDD && (
              <div className="mt-4 pt-4 border-t border-border">
                <p className="text-sm text-muted-foreground">
                  DDD selecionado: <span className="text-foreground font-semibold">{selectedDDD}</span>
                </p>
              </div>
            )}
          </div>

          {/* Passo 2: Dígitos Centrais */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold bg-foreground text-background">2</div>
              <h2 className="text-lg font-semibold text-foreground">Dígitos centrais (aleatórios)</h2>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="flex-1 bg-background border border-border rounded-lg px-4 py-3 font-mono text-lg text-foreground tracking-widest text-center">
                {centralDigits}
              </div>
              <Button
                variant="outline"
                size="icon"
                className="h-12 w-12 border-border text-foreground hover:bg-foreground/10"
                onClick={generateCentralDigits}
                disabled={isAnimating}
              >
                <RefreshCw className={cn("h-5 w-5", isAnimating && "animate-spin")} />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Clique no botão ao lado para gerar novos dígitos centrais
            </p>
          </div>

          {/* Passo 3: Últimos 4 Dígitos */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold bg-foreground text-background">3</div>
              <h2 className="text-lg font-semibold text-foreground">Escolha os últimos 4 dígitos</h2>
            </div>
            
            <div className="space-y-2">
              <label className="sr-only" htmlFor="lastFour">
                Últimos 4 dígitos
              </label>
              <Input
                id="lastFour"
                type="tel"
                placeholder="0000"
                maxLength={4}
                value={lastFour}
                onChange={handleLastFourChange}
                className="h-14 text-center font-mono text-2xl tracking-[0.5em] bg-background border-border text-foreground placeholder:text-muted-foreground"
              />
              <p className="text-xs text-muted-foreground">
                Digite os 4 números que você quer no final do seu número
              </p>
            </div>
          </div>

          {/* Resumo e Ação (Aparece apenas quando os 4 dígitos estão preenchidos) */}
          {lastFour.length === 4 && (
            <div className="bg-card rounded-xl border-2 border-foreground/20 p-6 animate-in fade-in slide-in-from-bottom-4">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="h-5 w-5 text-foreground" />
                <h3 className="text-lg font-semibold text-foreground">Seu número será:</h3>
              </div>
              
              <div className="bg-background border border-border rounded-xl p-6 text-center mb-6">
                <p className="text-3xl sm:text-4xl font-bold font-mono text-foreground tracking-wide">
                  {selectedDDD ? `(${selectedDDD})` : "(__)"} {centralDigits}-{lastFour}
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-green-600/10 border border-green-600/30 rounded-lg p-4">
                  <Check className="h-6 w-6 text-green-600 flex-shrink-0" />
                  <div>
                    <p className="text-green-600 font-semibold">Número disponível!</p>
                    <p className="text-sm text-muted-foreground">Este número está pronto para ser ativado.</p>
                  </div>
                </div>
                
                <Button 
                  className="w-full h-auto py-6 text-lg font-semibold group"
                  onClick={handleContinue}
                >
                  Continuar com este número
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default EscolherNumero;