import { useState, useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { User, Mail, Phone, CreditCard, Wifi, Smartphone, Check, Shield, ArrowRight, MapPin, Loader2, Copy, CheckCircle2, Clock, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { QRCodeSVG } from "qrcode.react";
import { supabase } from "@/integrations/supabase/client";

// Tipagem para os Pixels
declare global {
  interface Window {
    fbq: any;
    ttq: any;
  }
}

const Checkout = () => {
  const location = useLocation();
  const state = location.state || {};
  
  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  // Dados vindos da navegação ou padrões para visualização
  const plan = state.plan || { id: 2, gb: "450 GB", price: "49,00" };
  const type = state.type || "virtual";
  const selectedDDD = state.selectedDDD || "95";
  const centralDigits = state.centralDigits || "94437";
  const lastFour = state.lastFour || "8876";
  
  const fullNumber = `(${selectedDDD}) ${centralDigits}-${lastFour}`;
  const isVirtual = type === "virtual";

  // Cálculos de preço
  const planPrice = parseFloat(plan.price.replace(",", "."));
  // Se não veio do state, assume 9.99 para físico e 0 para virtual
  const shippingCost = state.shippingCost !== undefined ? state.shippingCost : (isVirtual ? 0 : 9.99);
  const total = planPrice + shippingCost;

  // Estados do formulário
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [cpf, setCpf] = useState("");
  const [cpfError, setCpfError] = useState(false);
  
  // Endereço
  const [loadingCep, setLoadingCep] = useState(false);
  const [address, setAddress] = useState({
    cep: "",
    street: "",
    number: "",
    neighborhood: "",
    city: "",
    complement: ""
  });

  // Estados de Pagamento e UI
  const [loadingPay, setLoadingPay] = useState(false);
  const [step, setStep] = useState(1); // 1: Dados, 2: Pagamento (Pix), 3: Confirmado
  const [pixData, setPixData] = useState<any>(null);
  const [transactionId, setTransactionId] = useState<string | number | null>(null);

  // Função para verificar status
  const checkPaymentStatus = async () => {
    if (!transactionId) return;

    try {
      // Chama a Edge Function em vez da API direta
      const { data, error } = await supabase.functions.invoke('gestao-payment', {
        body: {
          action: 'check',
          transactionId: transactionId
        }
      });

      if (error) {
        throw error;
      }
      
      const status = data.data?.status?.toUpperCase();

      // Verifica status de pagamento confirmado
      if (status === "PAID" || status === "APPROVED" || status === "CONFIRMED") {
        setStep(3);
        toast.success("Pagamento confirmado com sucesso!");

        // Disparar evento de conversão do Facebook
        if (window.fbq) {
          window.fbq('track', 'Purchase', {
            value: total,
            currency: 'BRL',
            content_name: `Chip Starlink ${plan.gb}`,
            content_type: 'product'
          });
        }

        // Disparar evento de conversão do TikTok
        if (window.ttq) {
          window.ttq.track('CompletePayment', {
            content_id: `plan_${plan.id}`,
            quantity: 1,
            price: total,
            value: total,
            currency: 'BRL',
          });
        }

        // Atualizar status no Supabase
        await supabase
          .from('orders')
          .update({ status: 'Paid' })
          .eq('transaction_id', transactionId.toString());
      }
    } catch (error) {
      console.error("Erro ao verificar status:", error);
    }
  };

  // Monitoramento de Status de Pagamento Automático
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (step === 2 && transactionId) {
      // Verificar imediatamente
      checkPaymentStatus();

      // Verificar a cada 5 segundos
      interval = setInterval(() => {
        checkPaymentStatus();
      }, 5000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [step, transactionId]);

  // Validação de CPF
  const validateCpf = (strCPF: string) => {
    let sum;
    let remainder;
    sum = 0;
    const cleanCPF = strCPF.replace(/\D/g, "");
    
    if (cleanCPF === "00000000000" || cleanCPF.length !== 11) return false;

    for (let i = 1; i <= 9; i++) sum = sum + parseInt(cleanCPF.substring(i - 1, i)) * (11 - i);
    remainder = (sum * 10) % 11;
    if ((remainder === 10) || (remainder === 11)) remainder = 0;
    if (remainder !== parseInt(cleanCPF.substring(9, 10))) return false;

    sum = 0;
    for (let i = 1; i <= 10; i++) sum = sum + parseInt(cleanCPF.substring(i - 1, i)) * (12 - i);
    remainder = (sum * 10) % 11;
    if ((remainder === 10) || (remainder === 11)) remainder = 0;
    if (remainder !== parseInt(cleanCPF.substring(10, 11))) return false;
    
    return true;
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, "");
    if (value.length > 11) value = value.slice(0, 11);
    
    value = value.replace(/(\d{3})(\d)/, "$1.$2");
    value = value.replace(/(\d{3})(\d)/, "$1.$2");
    value = value.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
    
    setCpf(value);
    if (cpfError) setCpfError(false);
  };

  const handleCpfBlur = () => {
    if (cpf && !validateCpf(cpf)) {
      setCpfError(true);
      toast.error("CPF inválido. Por favor, verifique.");
    }
  };

  const handleCepChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "");
    setAddress(prev => ({ ...prev, cep: value }));

    if (value.length === 8) {
      setLoadingCep(true);
      try {
        const response = await fetch(`https://viacep.com.br/ws/${value}/json/`);
        const data = await response.json();

        if (data.erro) {
          toast.error("CEP não encontrado.");
          return;
        }

        setAddress(prev => ({
          ...prev,
          street: data.logradouro,
          neighborhood: data.bairro,
          city: `${data.localidade} - ${data.uf}`,
          complement: data.complemento || ""
        }));
        
        toast.success("Endereço encontrado!");
      } catch (error) {
        toast.error("Erro ao buscar CEP. Verifique sua conexão.");
      } finally {
        setLoadingCep(false);
      }
    }
  };

  const handleAddressChange = (field: string, value: string) => {
    setAddress(prev => ({ ...prev, [field]: value }));
  };

  const handleGeneratePix = async () => {
    // Validação básica
    if (!name || !email || !phone || !cpf || (cpfError)) {
      toast.error("Por favor, preencha todos os campos corretamente.");
      return;
    }
    
    if (!isVirtual && (!address.street || !address.number || !address.city)) {
       toast.error("Por favor, preencha o endereço de entrega.");
       return;
    }

    setLoadingPay(true);

    const amountInCents = Math.round(total * 100);
    const cleanPhone = phone.replace(/\D/g, "");
    const formattedPhone = cleanPhone.startsWith("55") ? `+${cleanPhone}` : `+55${cleanPhone}`;

    const requestBody = {
      payment_method: "pix",
      customer: {
        document: {
          type: "cpf",
          number: cpf.replace(/\D/g, "")
        },
        name: name,
        email: email,
        phone: formattedPhone
      },
      amount: amountInCents,
      items: [
        {
          title: `Chip Starlink ${plan.gb}`,
          unit_price: amountInCents,
          quantity: 1,
          external_ref: `plano_${plan.id}`
        }
      ],
      installments: 1,
      metadata: {
        provider_name: "Starlink Partner"
      }
    };

    try {
      // Chama a Edge Function para criar a transação
      const { data, error } = await supabase.functions.invoke('gestao-payment', {
        body: {
          action: 'create',
          payload: requestBody
        }
      });

      if (error) {
        throw error;
      }

      console.log("Create transaction response:", data);
      
      if (data && data.success && data.data) {
        setPixData(data.data);
        
        const newTransactionId = data.data.id;
        
        if (!newTransactionId) {
          console.error("ID da transação não encontrado na resposta:", data);
          toast.error("Erro ao processar resposta do pagamento.");
          setLoadingPay(false);
          return;
        }

        setTransactionId(newTransactionId);
        setStep(2);

        // Salvar no Supabase
        const { error: dbError } = await supabase.from('orders').insert({
          customer_name: name,
          customer_email: email,
          customer_phone: formattedPhone,
          customer_cpf: cpf,
          plan_name: plan.gb,
          amount: total,
          status: data.data.status || 'PENDING',
          transaction_id: newTransactionId.toString(),
          pix_code: data.data.pix?.qr_code,
          type: type,
          address: isVirtual ? null : address,
          purchased_number: fullNumber
        });

        if (dbError) {
          console.error("Erro ao salvar pedido no banco:", dbError);
          toast.error("Erro ao salvar o pedido, mas o PIX foi gerado.");
        } else {
          toast.success("Pedido registrado com sucesso!");
        }

        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        toast.error("Erro ao gerar PIX. Verifique os dados e tente novamente.");
        console.error("Erro na API:", data);
      }

    } catch (error) {
      console.error(error);
      toast.error("Erro de conexão com o servidor de pagamento.");
    } finally {
      setLoadingPay(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Código copiado!");
  };

  // Extrair o código Pix da resposta da API
  const getPixCode = () => {
    if (!pixData) return "";
    return pixData.pix?.qr_code || "";
  };

  return (
    <div className="min-h-screen bg-background font-sans antialiased">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link to="/" className="flex items-center gap-3">
             <img 
              src="/starlogo.png" 
              alt="Starlink" 
              className="h-8 w-auto object-contain" 
            />
            <span className="text-foreground font-semibold">Starlink Partner Solutions</span>
          </Link>
        </div>
      </header>

      {/* Steps Indicator */}
      <div className="border-b border-border bg-card/50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-center gap-4 text-sm">
            <div className={`flex items-center gap-2 ${step >= 1 ? "text-foreground" : "text-muted-foreground"}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${step >= 1 ? "bg-foreground text-background" : "bg-muted text-muted-foreground"}`}>1</div>
              <span className="hidden sm:inline font-medium">Dados</span>
            </div>
            <div className="w-12 h-px bg-border"></div>
            <div className={`flex items-center gap-2 ${step >= 2 ? "text-foreground" : "text-muted-foreground"}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${step >= 2 ? "bg-foreground text-background" : "bg-muted text-muted-foreground"}`}>2</div>
              <span className="hidden sm:inline font-medium">Pagamento</span>
            </div>
            <div className="w-12 h-px bg-border"></div>
            <div className={`flex items-center gap-2 ${step >= 3 ? "text-foreground" : "text-muted-foreground"}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${step >= 3 ? "bg-foreground text-background" : "bg-muted text-muted-foreground"}`}>3</div>
              <span className="hidden sm:inline font-medium">Confirmação</span>
            </div>
          </div>
        </div>
      </div>

      {/* Number Banner */}
      <div className="border-b border-border bg-green-600/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-center gap-2 text-sm">
            <span className="text-muted-foreground">Número escolhido:</span>
            <span className="text-foreground font-mono font-bold">{fullNumber}</span>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        <div className="grid lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Main Column */}
          <div className="lg:col-span-3">
            
            {step === 1 && (
              <div className="bg-card rounded-xl border border-border p-6 sm:p-8 animate-in fade-in slide-in-from-left-4">
                <h2 className="text-2xl font-bold text-foreground mb-2">Seus Dados</h2>
                <p className="text-muted-foreground mb-8">Preencha seus dados para continuar com a ativação</p>
                
                <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                  <div className="space-y-2">
                    <Label htmlFor="name" className="flex items-center gap-2">Nome Completo</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input 
                        id="name" 
                        placeholder="Seu nome completo" 
                        className="pl-10 h-12 bg-background"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="flex items-center gap-2">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input 
                        id="email" 
                        type="email" 
                        placeholder="seu@email.com" 
                        className="pl-10 h-12 bg-background"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="flex items-center gap-2">Telefone / WhatsApp</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input 
                        id="phone" 
                        type="tel" 
                        placeholder="(00) 00000-0000" 
                        className="pl-10 h-12 bg-background"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cpf" className="flex items-center gap-2">CPF</Label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                      <Input 
                        id="cpf" 
                        placeholder="000.000.000-00" 
                        className={`pl-10 h-12 bg-background ${cpfError ? "border-red-500 focus-visible:ring-red-500" : ""}`}
                        value={cpf}
                        onChange={handleCpfChange}
                        onBlur={handleCpfBlur}
                        maxLength={14}
                      />
                    </div>
                    {cpfError && (
                      <p className="text-sm text-red-500 animate-in fade-in slide-in-from-top-1">
                        CPF inválido. Verifique os dígitos.
                      </p>
                    )}
                  </div>

                  {!isVirtual && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-500">
                      <div className="pt-4 border-t border-border mt-6">
                        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                          <MapPin className="h-5 w-5" />
                          Endereço de Entrega
                        </h3>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="cep">CEP</Label>
                        <div className="relative">
                          <Input 
                            id="cep" 
                            placeholder="00000-000" 
                            className="h-12 bg-background pr-10"
                            value={address.cep}
                            onChange={handleCepChange}
                            maxLength={9}
                          />
                          {loadingCep && (
                            <div className="absolute right-3 top-1/2 -translate-y-1/2">
                              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-4">
                        <div className="col-span-3 space-y-2">
                          <Label htmlFor="street">Rua</Label>
                          <Input 
                            id="street" 
                            placeholder="Nome da rua" 
                            className="h-12 bg-background"
                            value={address.street}
                            onChange={(e) => handleAddressChange("street", e.target.value)}
                          />
                        </div>
                        <div className="col-span-1 space-y-2">
                          <Label htmlFor="number">Número</Label>
                          <Input 
                            id="number" 
                            placeholder="123" 
                            className="h-12 bg-background"
                            value={address.number}
                            onChange={(e) => handleAddressChange("number", e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="neighborhood">Bairro</Label>
                          <Input 
                            id="neighborhood" 
                            placeholder="Bairro" 
                            className="h-12 bg-background"
                            value={address.neighborhood}
                            onChange={(e) => handleAddressChange("neighborhood", e.target.value)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="city">Cidade - UF</Label>
                          <Input 
                            id="city" 
                            placeholder="Cidade - UF" 
                            className="h-12 bg-background"
                            value={address.city}
                            onChange={(e) => handleAddressChange("city", e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="complement">Complemento (opcional)</Label>
                        <Input 
                          id="complement" 
                          placeholder="Apto, Bloco, etc." 
                          className="h-12 bg-background"
                          value={address.complement}
                          onChange={(e) => handleAddressChange("complement", e.target.value)}
                        />
                      </div>
                    </div>
                  )}

                  <Button 
                    onClick={handleGeneratePix}
                    disabled={loadingPay}
                    className="w-full h-auto py-6 text-lg font-semibold group mt-4"
                  >
                    {loadingPay ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Gerando PIX...
                      </>
                    ) : (
                      <>
                        Gerar PIX para Pagamento
                        <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </Button>
                </form>
              </div>
            )}

            {step === 2 && pixData && (
              <div className="bg-card rounded-xl border border-border p-6 sm:p-8 animate-in fade-in slide-in-from-right-4">
                <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-yellow-500/10 mb-4 animate-pulse">
                    <Clock className="h-8 w-8 text-yellow-500" />
                  </div>
                  <h2 className="text-2xl font-bold text-foreground">Aguardando Pagamento</h2>
                  <p className="text-muted-foreground mt-2">
                    Escaneie o QR Code abaixo ou copie o código
                  </p>
                </div>

                <div className="flex flex-col items-center justify-center mb-8 bg-white p-6 rounded-xl border border-border max-w-sm mx-auto">
                   <QRCodeSVG value={getPixCode()} size={220} />
                </div>

                <div className="space-y-4 max-w-lg mx-auto">
                  <div className="space-y-2">
                    <Label className="text-center block">Código Copia e Cola</Label>
                    <div className="flex gap-2">
                      <Input 
                        readOnly 
                        value={getPixCode()} 
                        className="bg-background font-mono text-xs"
                      />
                      <Button 
                        variant="outline" 
                        size="icon" 
                        onClick={() => copyToClipboard(getPixCode())}
                        title="Copiar código"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-4 text-center">
                     <p className="text-sm text-blue-800 dark:text-blue-200 flex items-center justify-center gap-2 mb-0">
                       <Loader2 className="h-4 w-4 animate-spin" />
                       Aguardando confirmação automática...
                     </p>
                  </div>
                  
                  <Button 
                    variant="outline"
                    className="w-full mt-4"
                    onClick={() => window.location.reload()}
                  >
                    Cancelar
                  </Button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="bg-card rounded-xl border border-border p-6 sm:p-8 animate-in fade-in zoom-in duration-500">
                <div className="text-center mb-8">
                  <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-600/20 mb-6">
                    <CheckCircle2 className="h-10 w-10 text-green-600" />
                  </div>
                  <h2 className="text-3xl font-bold text-foreground mb-4">Pagamento Confirmado!</h2>
                  <p className="text-lg text-muted-foreground max-w-md mx-auto">
                    Parabéns! Seu pagamento foi realizado com sucesso.
                  </p>
                </div>

                <div className="bg-green-600/10 border border-green-600/20 rounded-xl p-6 mb-8 max-w-md mx-auto text-center">
                  <h3 className="text-xl font-bold text-foreground mb-2">
                    Finalizar Ativação
                  </h3>
                  <p className="text-sm text-muted-foreground mb-6">
                    Para concluir a ativação do seu chip e liberar o acesso, entre em contato com o Suporte Starlink agora mesmo.
                  </p>
                  
                  <a 
                    href="https://wa.me/5511919700247?text=Ol%C3%A1%2C%20gostaria%20de%20ativar%20o%20meu%20chip%2C%20j%C3%A1%20realizei%20o%20pagamento%20!%20"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button size="lg" className="w-full bg-green-600 hover:bg-green-700 text-white rounded-full group h-auto py-4">
                      <MessageCircle className="mr-2 h-5 w-5" />
                      Falar com Suporte no WhatsApp
                    </Button>
                  </a>
                </div>

                <div className="text-center">
                  <Link to="/">
                    <Button variant="outline" className="rounded-full px-8">
                      Voltar ao Início
                    </Button>
                  </Link>
                </div>
              </div>
            )}
          </div>

          {/* Summary Column (Right) */}
          <div className="lg:col-span-2">
            <div className="bg-card rounded-xl border border-border p-6 sm:p-8 sticky top-8">
              <h3 className="text-lg font-bold text-foreground mb-6">Resumo do Pedido</h3>
              
              <div className="flex gap-4 mb-6">
                <div className="w-16 h-16 rounded-lg bg-foreground/10 flex items-center justify-center shrink-0">
                  <Wifi className="h-8 w-8 text-foreground" />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">Chip Starlink {plan.gb}</h4>
                  <p className="text-sm text-muted-foreground">Direct-to-Cell</p>
                  <p className="text-sm text-muted-foreground">Plano mensal</p>
                </div>
              </div>

              <div className="flex items-center gap-3 bg-foreground/5 rounded-lg p-3 mb-6">
                <Smartphone className="h-5 w-5 text-foreground" />
                <div>
                  <p className="text-foreground font-medium text-sm">
                    {isVirtual ? "Chip Virtual (eSIM)" : "Chip Físico"}
                  </p>
                  <p className="text-muted-foreground text-xs">
                    {isVirtual ? "Ativação no mesmo dia" : "Envio via Correios"}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 bg-green-600/10 border border-green-600/30 rounded-lg p-3 mb-6">
                <Phone className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-foreground font-semibold text-sm">Seu número</p>
                  <p className="text-green-600 font-mono text-base font-bold">{fullNumber}</p>
                </div>
              </div>

              <div className="border-t border-border my-6"></div>

              <div className="space-y-3 mb-6">
                {[
                  "2 meses de uso grátis",
                  "App oficial para Android e iOS",
                  "Suporte técnico em português",
                  "Sem fidelidade ou contratos",
                  "Cancele quando quiser"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                     <div className="w-5 h-5 rounded-full bg-foreground/10 flex items-center justify-center shrink-0">
                        <Check className="h-3 w-3 text-foreground" />
                     </div>
                     <span className="text-sm text-muted-foreground">{item}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-border my-6"></div>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Compra do Chip ({plan.gb})</span>
                  <span className="text-foreground">R$ {plan.price}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Taxa de envio</span>
                  <span className={isVirtual ? "text-green-600 font-semibold" : "text-foreground"}>
                    {shippingCost === 0 ? "Grátis" : `R$ ${shippingCost.toFixed(2).replace(".", ",")}`}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Período de teste</span>
                  <span className="text-foreground">2 meses grátis</span>
                </div>
              </div>

              <div className="border-t border-border my-6"></div>

              <div className="flex justify-between items-baseline mb-6">
                <span className="text-foreground font-medium">Total hoje:</span>
                <div className="text-right">
                  <span className="text-2xl font-bold text-foreground">
                    R$ {total.toFixed(2).replace(".", ",")}
                  </span>
                </div>
              </div>

              <div className="bg-foreground/5 rounded-lg p-4 mb-6">
                <p className="text-sm text-muted-foreground">
                  Após 2 meses de uso grátis, será cobrada a mensalidade de <span className="text-foreground font-semibold">R$ {plan.price}/mês</span>. Cancele quando quiser.
                </p>
              </div>

              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Shield className="h-4 w-4" />
                <span>Pagamento 100% seguro</span>
              </div>

              <div className="flex items-center justify-center gap-2 mt-6 pt-6 border-t border-border">
                <img src="/starlogo.png" alt="Starlink" className="h-6 w-auto opacity-50 grayscale" />
                <span className="text-xs text-muted-foreground">Parceiro Autorizado</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Checkout;
