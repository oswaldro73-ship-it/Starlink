import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { DollarSign, Users, Clock, CheckCircle, MapPin, Phone, LogOut } from "lucide-react";
import { toast } from "sonner";

interface Address {
  cep: string;
  street: string;
  number: string;
  neighborhood: string;
  city: string;
  complement: string;
}

interface Order {
  id: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  customer_cpf: string;
  plan_name: string;
  amount: number;
  status: string;
  created_at: string;
  type: string;
  address?: Address;
  purchased_number?: string;
}

const Manager = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchOrders = async () => {
    try {
      const { data, error } = await supabase
        .from("orders")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setOrders(data || []);
    } catch (error) {
      console.error("Erro ao buscar pedidos:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
    fetchOrders();

    const channel = supabase
      .channel('public:orders')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, fetchOrders)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("admin_auth");
    localStorage.removeItem("admin_auth_time");
    toast.success("Logout realizado com sucesso");
    navigate("/login");
  };

  const totalSales = orders.reduce((acc, order) => acc + Number(order.amount), 0);
  const totalOrders = orders.length;
  const pendingOrders = orders.filter(o => o.status === 'Waiting Payment' || o.status === 'pending').length;
  const paidOrders = orders.filter(o => o.status === 'Paid' || o.status === 'paid' || o.status === 'CONFIRMED').length;

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-[1400px] mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-foreground">Painel Gerencial</h1>
          <Button variant="outline" onClick={handleLogout} className="gap-2">
            <LogOut className="h-4 w-4" />
            Sair
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Vendas Totais</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R$ {totalSales.toFixed(2).replace('.', ',')}</div>
              <p className="text-xs text-muted-foreground">Volume total transacionado</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Pedidos</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalOrders}</div>
              <p className="text-xs text-muted-foreground">Clientes cadastrados</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
              <Clock className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{pendingOrders}</div>
              <p className="text-xs text-muted-foreground">Aguardando pagamento</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pagos</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{paidOrders}</div>
              <p className="text-xs text-muted-foreground">Transações concluídas</p>
            </CardContent>
          </Card>
        </div>

        {/* Orders Table */}
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Últimos Pedidos</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p>Carregando...</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>CPF</TableHead>
                    <TableHead>Núm. Comprado</TableHead>
                    <TableHead>Plano</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Tipo / Entrega</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="whitespace-nowrap">{format(new Date(order.created_at), "dd/MM HH:mm")}</TableCell>
                      <TableCell>
                        <div className="font-medium">{order.customer_name}</div>
                        <div className="text-xs text-muted-foreground">{order.customer_email}</div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                          <Phone className="h-3 w-3" />
                          {order.customer_phone}
                        </div>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">{order.customer_cpf}</TableCell>
                      <TableCell className="whitespace-nowrap font-mono text-sm font-bold">
                        {order.purchased_number || "-"}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">{order.plan_name}</TableCell>
                      <TableCell className="whitespace-nowrap">R$ {Number(order.amount).toFixed(2).replace('.', ',')}</TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          <span className="capitalize text-sm font-medium">{order.type}</span>
                          {order.type === 'fisico' && order.address && (
                            <Popover>
                              <PopoverTrigger asChild>
                                <Button variant="outline" size="sm" className="h-6 text-xs w-fit">
                                  <MapPin className="h-3 w-3 mr-1" /> Ver Endereço
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-80">
                                <div className="space-y-2">
                                  <h4 className="font-medium leading-none">Endereço de Entrega</h4>
                                  <div className="text-sm text-muted-foreground">
                                    <p>{order.address.street}, {order.address.number}</p>
                                    {order.address.complement && <p>{order.address.complement}</p>}
                                    <p>{order.address.neighborhood}</p>
                                    <p>{order.address.city}</p>
                                    <p>{order.address.cep}</p>
                                  </div>
                                </div>
                              </PopoverContent>
                            </Popover>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={
                            order.status === 'Paid' || order.status === 'CONFIRMED' ? 'default' : 
                            order.status === 'Waiting Payment' || order.status === 'pending' ? 'secondary' : 'destructive'
                          }
                          className={
                            order.status === 'Paid' || order.status === 'CONFIRMED' ? 'bg-green-600 hover:bg-green-700' : ''
                          }
                        >
                          {order.status === 'Waiting Payment' ? 'Aguardando Pagamento' : order.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Manager;