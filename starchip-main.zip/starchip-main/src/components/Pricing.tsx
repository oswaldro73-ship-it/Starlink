import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  CreditCard,
  Download,
  Wifi,
  Smartphone,
  Zap,
  Phone,
  Check,
  ArrowRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const PLANS = [
  {
    id: 1,
    gb: "10 GB Teste",
    price: "9,90",
    popular: false,
    features: [
      "1 Conexão Teste Simultânea",
      "Sinal Via Satélite",
      "Chip Virtual / Físico",
    ],
  },
  {
    id: 2,
    gb: "450 GB",
    price: "49,00",
    popular: true,
    features: [
      "3 Conexões Simultâneas",
      "Sinal Via Satélite",
      "Chip Virtual / Físico",
    ],
  },
  {
    id: 3,
    gb: "600 GB",
    price: "149,90",
    popular: false,
    features: [
      "6 Conexões Simultâneas",
      "Velocidade Extraordinária",
      "Sinal Via Satélite",
      "Chip Físico",
    ],
  },
];

export const Pricing = () => {
  const [selectedPlan, setSelectedPlan] = useState(PLANS[1]); // Default to popular plan
  const navigate = useNavigate();

  const handleSubscribe = () => {
    navigate("/escolher-chip", { state: { plan: selectedPlan } });
  };

  return (
    <section id="oferta" className="py-24 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
            Adquira Seu Plano Starlink
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Escolha o plano ideal para você e comece a usar hoje mesmo
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-20">
          {[
            {
              step: "1",
              icon: CreditCard,
              title: "Escolha seu Plano",
              desc: "Selecione o plano que melhor atende às suas necessidades.",
            },
            {
              step: "2",
              icon: Download,
              title: "Baixe o App",
              desc: "Instale o App Modem Virtual disponível para Android e iOS.",
            },
            {
              step: "3",
              icon: Wifi,
              title: "Conecte-se",
              desc: "Pronto! Seu celular agora funciona como um modem via satélite.",
            },
          ].map((item, index) => (
            <div
              key={index}
              className="relative p-6 rounded-lg bg-background border border-border/50 text-center"
            >
              <div className="w-10 h-10 rounded-full bg-foreground text-background font-bold flex items-center justify-center mx-auto mb-4">
                {item.step}
              </div>
              <div className="w-12 h-12 rounded-lg bg-foreground/10 flex items-center justify-center mx-auto mb-4">
                <item.icon className="h-6 w-6 text-foreground" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">
                {item.title}
              </h3>
              <p className="text-muted-foreground text-sm">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="max-w-5xl mx-auto mb-16">
          <div className="p-6 rounded-2xl bg-gradient-to-br from-foreground/5 to-foreground/10 border border-foreground/20">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-full bg-foreground/10 flex items-center justify-center">
                <Smartphone className="h-6 w-6 text-foreground" />
              </div>
              <h3 className="text-xl font-bold text-foreground">
                Já Tem Outro Chip? Sem Problemas!
              </h3>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  icon: Zap,
                  title: "Chip Virtual (eSIM)",
                  desc: "O chip Starlink pode ser ativado virtualmente no seu celular, sem precisar de espaço físico.",
                },
                {
                  icon: Phone,
                  title: "Mantenha Seu Número",
                  desc: "Não precisa trocar de número! Você receberá um novo número Starlink e poderá usar ambos.",
                },
                {
                  icon: Smartphone,
                  title: "Uso Simultâneo",
                  desc: "Use os dois chips ao mesmo tempo: seu chip atual + o chip Starlink, sem nenhuma interferência.",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className="p-4 bg-background rounded-xl text-center"
                >
                  <div className="w-10 h-10 rounded-full bg-foreground/10 flex items-center justify-center mx-auto mb-3">
                    <item.icon className="h-5 w-5 text-foreground" />
                  </div>
                  <p className="text-foreground font-semibold mb-2">
                    {item.title}
                  </p>
                  <p className="text-muted-foreground text-sm">{item.desc}</p>
                </div>
              ))}
            </div>
            <p className="text-center text-foreground/80 text-sm mt-6 font-medium">
              Após a ativação, você receberá seu novo número Starlink e poderá
              aproveitar a conexão via satélite junto com sua operadora atual.
            </p>
          </div>
        </div>

        <div className="max-w-5xl mx-auto" id="ativar">
          <div className="text-center mb-8">
            <span className="inline-block bg-foreground text-background px-6 py-2 rounded-full text-sm font-semibold">
              2 Meses de Uso Grátis
            </span>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {PLANS.map((plan) => (
              <div
                key={plan.id}
                onClick={() => setSelectedPlan(plan)}
                className={`relative p-6 rounded-2xl bg-background border-2 cursor-pointer transition-all ${
                  selectedPlan.id === plan.id
                    ? "border-foreground shadow-lg shadow-foreground/20 ring-1 ring-foreground"
                    : "border-border hover:border-foreground/50"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="bg-foreground text-background px-4 py-1 rounded-full text-xs font-semibold">
                      Mais Popular
                    </span>
                  </div>
                )}
                <div className="bg-foreground text-background rounded-lg px-4 py-2 inline-block mb-4">
                  <span className="text-xl font-bold">{plan.gb}</span>
                </div>
                <div className="mb-6">
                  <div className="flex items-baseline gap-1">
                    <span className="text-lg text-muted-foreground">R$</span>
                    <span className="text-4xl font-bold text-foreground">
                      {plan.price}
                    </span>
                    <span className="text-muted-foreground">/mês</span>
                  </div>
                </div>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <div className="flex-shrink-0 h-5 w-5 rounded-full bg-foreground/10 flex items-center justify-center">
                        <Check className="h-3 w-3 text-foreground" />
                      </div>
                      <span className="text-foreground text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                <div
                  className={`w-full py-2 rounded-lg text-center text-sm font-medium transition-colors ${
                    selectedPlan.id === plan.id
                      ? "bg-foreground text-background"
                      : "bg-foreground/5 text-muted-foreground"
                  }`}
                >
                  {selectedPlan.id === plan.id ? "Selecionado" : "Selecionar"}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-10 p-6 rounded-2xl bg-background border border-border">
            <h3 className="text-xl font-bold text-foreground mb-4 text-center">
              Como Funciona o Pagamento
            </h3>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div className="p-4">
                <div className="w-10 h-10 rounded-full bg-foreground text-background font-bold flex items-center justify-center mx-auto mb-3">
                  1
                </div>
                <p className="text-foreground font-semibold mb-1">
                  Compra do Chip
                </p>
                <p className="text-2xl font-bold text-foreground">
                  R$ {selectedPlan.price}
                </p>
                <p className="text-muted-foreground text-sm mt-1">
                  Valor do chip escolhido pago agora
                </p>
              </div>
              <div className="p-4">
                <div className="w-10 h-10 rounded-full bg-foreground text-background font-bold flex items-center justify-center mx-auto mb-3">
                  2
                </div>
                <p className="text-foreground font-semibold mb-1">
                  Ativação do Chip
                </p>
                <p className="text-lg font-medium text-foreground">
                  Diretamente com o gerente
                </p>
                <p className="text-muted-foreground text-sm mt-1">
                  Ativação Starlink personalizada
                </p>
              </div>
              <div className="p-4">
                <div className="w-10 h-10 rounded-full bg-foreground text-background font-bold flex items-center justify-center mx-auto mb-3">
                  3
                </div>
                <p className="text-foreground font-semibold mb-1">
                  Após 2 Meses
                </p>
                <p className="text-2xl font-bold text-foreground">
                  R$ {selectedPlan.price}
                </p>
                <p className="text-muted-foreground text-sm mt-1">
                  Primeira mensalidade do plano
                </p>
              </div>
            </div>
            <p className="text-center text-muted-foreground text-sm mt-4 border-t border-border pt-4">
              Você terá 2 meses de uso grátis. A primeira mensalidade só será
              cobrada após esse período. Cancele quando quiser.
            </p>
          </div>

          <div className="mt-10 text-center">
            <Button size="lg" className="h-auto py-6 px-12 text-lg rounded-full group" onClick={handleSubscribe}>
              Comprar Chip Agora
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <p className="text-center text-sm text-muted-foreground mt-4">
              Pagamento seguro via PIX - Cancele quando quiser
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
