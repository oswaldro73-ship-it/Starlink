import { ArrowRight, Satellite } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0 bg-black">
        <div className="absolute inset-0 bg-[url('/starlink.webp')] bg-cover bg-center opacity-90" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/60 to-background" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center animate-in fade-in zoom-in duration-700">
        <div className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full border border-border/50 bg-card/50 backdrop-blur-sm">
          <Satellite className="h-4 w-4 text-foreground" />
          <span className="text-sm font-medium text-foreground">
            Tecnologia Direct-to-Cell
          </span>
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-foreground mb-6 text-balance">
          Chip Virtual Starlink
        </h1>

        <p className="text-xl sm:text-2xl md:text-3xl font-light text-foreground/90 mb-4">
          Internet Via Satélite Direto no Seu Celular
        </p>

        <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto mb-10 text-pretty">
          Transforme seu smartphone em um modem via satélite. Com mais de 7.000
          satélites em órbita baixa, a Starlink leva conectividade para onde as
          redes tradicionais não chegam.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="#como-funciona">
            <Button size="lg" className="rounded-full text-lg h-auto py-6 px-8 group">
              Saiba Como Funciona
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </a>
        </div>

        <div className="grid grid-cols-3 gap-8 mt-16 pt-8 border-t border-border/30 max-w-2xl mx-auto">
          <div>
            <p className="text-2xl sm:text-3xl font-bold text-foreground">
              7.000+
            </p>
            <p className="text-sm text-muted-foreground">Satélites em órbita</p>
          </div>
          <div>
            <p className="text-2xl sm:text-3xl font-bold text-foreground">
              100+
            </p>
            <p className="text-sm text-muted-foreground">Países atendidos</p>
          </div>
          <div>
            <p className="text-2xl sm:text-3xl font-bold text-foreground">
              4M+
            </p>
            <p className="text-sm text-muted-foreground">Usuários ativos</p>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-foreground/30 flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-foreground/50 rounded-full"></div>
        </div>
      </div>
    </section>
  );
};