import { Satellite, Globe, Smartphone, Signal } from "lucide-react";

export const HowItWorks = () => {
  return (
    <section id="como-funciona" className="py-24 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 mb-6 rounded-full border border-border/50 bg-background/50">
            <Satellite className="h-4 w-4" />
            <span className="text-sm font-medium">
              Tecnologia Direct-to-Cell
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
            O Que é o Chip Virtual Starlink?
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">
            O Chip Virtual Starlink utiliza a revolucionária tecnologia
            Direct-to-Cell, que transforma os satélites em órbita em torres de
            celular no espaço. Isso significa que seu smartphone pode se conectar
            diretamente aos satélites, sem necessidade de antenas externas ou
            equipamentos adicionais.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div className="relative aspect-video rounded-lg overflow-hidden shadow-2xl">
            <img
              alt="Conectividade móvel via satélite"
              className="object-cover w-full h-full"
              src="/phone-call.png"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-foreground mb-4">
              Satélites como Torres de Celular no Espaço
            </h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              A constelação Starlink opera com mais de 7.000 satélites em órbita
              baixa (LEO), criando uma rede global de conectividade sem
              precedentes. Diferente da internet via satélite tradicional, a
              tecnologia Direct-to-Cell permite que qualquer smartphone moderno
              se conecte diretamente, transformando seu aparelho em um verdadeiro
              modem via satélite.
            </p>
            <ul className="space-y-3">
              {[
                "Funciona com qualquer smartphone Android ou iOS",
                "Não precisa de antena externa ou equipamentos",
                "Cobertura em áreas remotas, rurais e marítimas",
                "Ideal para viagens, barcos, fazendas e expedições",
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-3 text-foreground">
                  <div className="h-1.5 w-1.5 rounded-full bg-foreground" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: Globe,
              title: "Cobertura Global",
              desc: "Mais de 7.000 satélites em órbita baixa garantem cobertura em praticamente qualquer lugar do planeta, incluindo áreas onde as operadoras tradicionais não chegam.",
            },
            {
              icon: Smartphone,
              title: "Sem Equipamentos",
              desc: "Diferente da Starlink tradicional, você não precisa de antena ou equipamentos especiais. Seu smartphone atual é tudo que você precisa para se conectar.",
            },
            {
              icon: Signal,
              title: "Baixa Latência",
              desc: "Por operar em órbita baixa (550km), a Starlink oferece latência muito menor que satélites tradicionais, permitindo chamadas de vídeo, streaming e navegação fluida.",
            },
          ].map((item, index) => (
            <div
              key={index}
              className="relative p-8 rounded-lg bg-background border border-border/50 hover:border-foreground/20 transition-colors group"
            >
              <div className="w-12 h-12 rounded-lg bg-foreground/10 flex items-center justify-center mb-6">
                <item.icon className="h-6 w-6 text-foreground" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">
                {item.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};