import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-background/80 backdrop-blur-md border-b border-border/50" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <img 
              src="/starlogo.png" 
              alt="Starlink" 
              className="h-12 w-auto object-contain" 
            />
          </div>
          
          <nav className="hidden md:flex items-center gap-8">
            <a href="#como-funciona" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Como Funciona
            </a>
            <a href="#oferta" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Oferta
            </a>
            <a href="#transparencia" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
              Transparência
            </a>
          </nav>

          <div className="hidden md:block">
            <a href="#oferta">
              <Button className="rounded-full px-6">
                Ativar Agora
              </Button>
            </a>
          </div>

          <button
            className="md:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden bg-background border-b border-border/50 p-4 space-y-4 animate-in slide-in-from-top-5">
          <a
            href="#como-funciona"
            className="block text-sm font-medium text-muted-foreground hover:text-foreground"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Como Funciona
          </a>
          <a
            href="#oferta"
            className="block text-sm font-medium text-muted-foreground hover:text-foreground"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Oferta
          </a>
          <a
            href="#transparencia"
            className="block text-sm font-medium text-muted-foreground hover:text-foreground"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Transparência
          </a>
          <a href="#oferta" onClick={() => setIsMobileMenuOpen(false)}>
            <Button className="w-full rounded-full">Ativar Agora</Button>
          </a>
        </div>
      )}
    </header>
  );
};