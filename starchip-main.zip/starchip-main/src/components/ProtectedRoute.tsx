import { Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    // Verificação simples de sessão
    const auth = localStorage.getItem("admin_auth");
    const timestamp = localStorage.getItem("admin_auth_time");
    
    // Validar se a sessão existe e se não expirou (ex: 24h)
    const now = new Date().getTime();
    const isValid = auth === "true" && timestamp && (now - parseInt(timestamp) < 24 * 60 * 60 * 1000);

    if (!isValid) {
      // Limpar se for inválido
      localStorage.removeItem("admin_auth");
      localStorage.removeItem("admin_auth_time");
      setIsAuthenticated(false);
      if (auth) toast.error("Sessão expirada. Faça login novamente.");
    } else {
      setIsAuthenticated(true);
    }
  }, []);

  if (isAuthenticated === null) {
    return null; // Carregando...
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};