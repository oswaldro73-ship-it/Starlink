export const Footer = () => {
  return (
    <footer className="py-12 bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center">
            <img 
              src="/starlogo.png" 
              alt="Starlink" 
              className="h-12 w-auto object-contain opacity-60" 
            />
          </div>
          <nav className="flex flex-wrap items-center justify-center gap-6">
            <a href="#como-funciona" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Como Funciona
            </a>
            <a href="#oferta" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Oferta
            </a>
            <a href="#transparencia" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Transparência
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Termos de Uso
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Política de Privacidade
            </a>
          </nav>
          <p className="text-sm text-muted-foreground">
            © 2026 Chip Virtual Starlink. Todos os direitos reservados.
          </p>
        </div>
        <div className="mt-8 pt-8 border-t border-border/50">
          <p className="text-xs text-muted-foreground text-center max-w-3xl mx-auto">
            Este serviço é oferecido em parceria com a tecnologia Starlink
            Direct-to-Cell. Starlink é uma marca registrada da SpaceX. A
            disponibilidade do serviço pode variar de acordo com a localização e
            cobertura de satélites.
          </p>
        </div>
      </div>
    </footer>
  );
};