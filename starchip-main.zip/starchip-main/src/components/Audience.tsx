import { Tractor, Ship, Mountain, Car, Building2, Users } from "lucide-react";

export const Audience = () => {
  const items = [
    {
      icon: Tractor,
      title: "Produtores Rurais",
      desc: "Mantenha-se conectado na fazenda, monitore equipamentos IoT e gerencie seu negócio de qualquer lugar da propriedade.",
    },
    {
      icon: Ship,
      title: "Navegadores e Pescadores",
      desc: "Internet confiável em alto mar para comunicação, navegação GPS e emergências. Nunca mais fique isolado.",
    },
    {
      icon: Mountain,
      title: "Aventureiros e Viajantes",
      desc: "Trilhas, acampamentos e expedições em locais remotos com acesso garantido à internet para segurança e comunicação.",
    },
    {
      icon: Car,
      title: "Motoristas e Caminhoneiros",
      desc: "Conectividade nas estradas, mesmo em trechos sem cobertura de operadoras tradicionais.",
    },
    {
      icon: Building2,
      title: "Empresas em Áreas Remotas",
      desc: "Operações de mineração, construção civil e energia em locais isolados com internet estável.",
    },
    {
      icon: Users,
      title: "Comunidades Isoladas",
      desc: "Acesso à educação, telemedicina e serviços essenciais para comunidades em regiões sem infraestrutura.",
    },
  ];

  return (
    <section id="para-quem" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
            Para Quem é o Chip Virtual?
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto text-pretty">
            Se você precisa de internet em lugares onde as operadoras tradicionais
            não chegam, o Chip Virtual Starlink é a solução ideal para você.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item, index) => (
            <div
              key={index}
              className="p-6 rounded-lg bg-card border border-border/50 hover:border-foreground/20 transition-colors"
            >
              <div className="w-10 h-10 rounded-lg bg-foreground/10 flex items-center justify-center mb-4">
                <item.icon className="h-5 w-5 text-foreground" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">
                {item.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};