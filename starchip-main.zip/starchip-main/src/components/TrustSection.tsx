import { Shield, Award, Handshake } from "lucide-react";

export const TrustSection = () => {
  return (
    <section className="py-16 bg-card border-y border-border/50" id="transparencia">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-foreground/10 border border-foreground/20 mb-6">
            <Shield className="h-4 w-4 text-foreground" />
            <span className="text-sm font-medium text-foreground">
              Programa Oficial
            </span>
          </div>
          
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            ACESSO EXCLUSIVO ATRAVÉS DO PROGRAMA
            <br />
            <span className="text-foreground/80">
              STARLINK PARTNER SOLUTIONS
            </span>
          </h2>
          
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6 text-lg">
            Somos parceiros oficiais autorizados, garantindo a você acesso
            legítimo e seguro à tecnologia de internet via satélite mais avançada
            do mundo.
          </p>
          
          <p className="text-foreground/90 max-w-3xl mx-auto mb-8 text-base font-medium">
            Uma iniciativa conjunta com operadoras brasileiras para homologação e
            teste da rede Direct-to-Cell.
          </p>

          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-lg bg-foreground/5 border-2 border-foreground/30 mb-10 max-w-full overflow-hidden">
            <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-full bg-white overflow-hidden p-1">
              <img 
                src="/anatel2.png" 
                alt="Selo Anatel" 
                className="w-full h-full object-contain"
              />
            </div>
            <div className="text-left">
              <p className="text-xs text-muted-foreground uppercase tracking-wider">
                Selo de Credibilidade
              </p>
              <p className="text-sm font-semibold text-foreground truncate">
                Protocolo de Uso Autorizado ANATEL
              </p>
            </div>
          </div>

          <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
            <div className="flex flex-col items-center gap-3 p-4">
              <div className="w-12 h-12 rounded-full bg-foreground/10 flex items-center justify-center">
                <Award className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <p className="font-semibold text-foreground">Autorizada Starlink</p>
                <p className="text-sm text-muted-foreground">
                  Certificação oficial Starlink
                </p>
              </div>
            </div>
            <div className="flex flex-col items-center gap-3 p-4">
              <div className="w-12 h-12 rounded-full bg-foreground/10 flex items-center justify-center">
                <Shield className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <p className="font-semibold text-foreground">Acesso Garantido</p>
                <p className="text-sm text-muted-foreground">
                  Conexão direta à rede oficial
                </p>
              </div>
            </div>
            <div className="flex flex-col items-center gap-3 p-4">
              <div className="w-12 h-12 rounded-full bg-foreground/10 flex items-center justify-center">
                <Handshake className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <p className="font-semibold text-foreground">Suporte Dedicado</p>
                <p className="text-sm text-muted-foreground">
                  Atendimento especializado
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};